%PROSP1_startpath
% this small script just set the analysis path.
% you can change this cript to change the path to a new analys

curr_path= '/storages/LDATA/Arcara/PROSP1_analysis/'