function varargout = process_mfip_ft_sourceCORR( varargin )
% PROCESS_FT_SOURCESTATISTICS Call FieldTrip function ft_sourcestatistics.
%
% Reference: http://www.fieldtriptoolbox.org/reference/ft_sourcestatistics

% @=============================================================================
% This function is part of the Brainstorm software:
% https://neuroimage.usc.edu/brainstorm
% 
% Copyright (c)2000-2019 University of Southern California & McGill University
% This software is distributed under the terms of the GNU General Public License
% as published by the Free Software Foundation. Further details on the GPLv3
% license can be found at http://www.gnu.org/copyleft/gpl.html.
% 
% FOR RESEARCH PURPOSES ONLY. THE SOFTWARE IS PROVIDED "AS IS," AND THE
% UNIVERSITY OF SOUTHERN CALIFORNIA AND ITS COLLABORATORS DO NOT MAKE ANY
% WARRANTY, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF
% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, NOR DO THEY ASSUME ANY
% LIABILITY OR RESPONSIBILITY FOR THE USE OF THIS SOFTWARE.
%
% For more information type "brainstorm license" at command prompt.
% =============================================================================@
%
% Authors: 

eval(macro_method);
end


%% ===== GET DESCRIPTION =====
function sProcess = GetDescription() %#ok<DEFNU>
    % Description the process
    sProcess.Comment     = 'FieldTrip: ft_sourcestatistics_CORR';
    sProcess.Category    = 'stat2';
    sProcess.SubGroup    = 'mfip';
    sProcess.Index       = 1007;
    sProcess.Description = 'https://neuroimage.usc.edu/brainstorm/Tutorials/Statistics';
    % Definition of the input accepted by this process
    sProcess.InputTypes  = {'results',  'timefreq', 'matrix'};
    sProcess.OutputTypes = {'presults', 'ptimefreq'};
    sProcess.nInputs     = 2;
    sProcess.nMinFiles   = 1;
    % Definition of the options
    %sProcess = process_ft_timelockstatistics('DefineStatOptions', sProcess);
    % ===== INPUT OPTIONS =====
    sProcess.options.label1.Comment = '<B><U>Input options</U></B>:';
    sProcess.options.label1.Type    = 'label';
    % === SENSOR TYPES
    sProcess.options.sensortypes.Comment    = 'Sensor types (empty=all): ';
    sProcess.options.sensortypes.Type       = 'text';
    sProcess.options.sensortypes.Value      = 'EEG';
    sProcess.options.sensortypes.InputTypes = {'data'};
    % === TIME WINDOW ===
    sProcess.options.timewindow.Comment = 'Time window:';
    sProcess.options.timewindow.Type    = 'timewindow';
    sProcess.options.timewindow.Value   = [];
    % === SCOUTS SELECTION ===
    sProcess.options.scoutsel.Comment    = 'Use scouts';
    sProcess.options.scoutsel.Type       = 'scout_confirm';
    sProcess.options.scoutsel.Value      = {};
    sProcess.options.scoutsel.InputTypes = {'results'};
    % === SCOUT FUNCTION ===
    sProcess.options.scoutfunc.Comment   = {'Mean', 'PCA', 'All', 'Scout function:'};
    sProcess.options.scoutfunc.Type      = 'radio_line';
    sProcess.options.scoutfunc.Value     = 1;
    sProcess.options.scoutfunc.InputTypes = {'results'};
    % === ABSOLUTE VALUE
    sProcess.options.isabs.Comment    = 'Test absolute values';
    sProcess.options.isabs.Type       = 'checkbox';
    sProcess.options.isabs.Value      = 0;
    sProcess.options.isabs.Hidden     = 1;
    % === AVERAGE OVER TIME
    sProcess.options.avgtime.Comment    = 'Average over time';
    sProcess.options.avgtime.Type       = 'checkbox';
    sProcess.options.avgtime.Value      = 0;
    % === AVERAGE OVER CHANNELS
    sProcess.options.avgchan.Comment    = 'Average over channels';
    sProcess.options.avgchan.Type       = 'checkbox';
    sProcess.options.avgchan.Value      = 0;
    sProcess.options.avgchan.InputTypes = {'data', 'timefreq', 'matrix'};
    % === AVERAGE OVER FREQUENCY
    sProcess.options.avgfreq.Comment    = 'Average over frequency';
    sProcess.options.avgfreq.Type       = 'checkbox';
    sProcess.options.avgfreq.Value      = 0;
    sProcess.options.avgfreq.InputTypes = {'timefreq'};
    % === UNCONSTRAINED SOURCES
    sProcess.options.label_norm.Comment    = ['<FONT color="#777777">Note: For unconstrained sources, "absolute value" refers to the norm<BR>' ...
                                              'of the three orientations: abs(F) = sqrt(Fx^2 + Fy^2 + Fz^2).</FONT>'];
    sProcess.options.label_norm.Type       = 'label';
    sProcess.options.label_norm.InputTypes = {'results'};
    % ===== STATISTICAL TESTING OPTIONS =====
    sProcess.options.label2.Comment  = '<BR><B><U>Statistical testing (Monte-Carlo)</U></B>:';
    sProcess.options.label2.Type     = 'label';
    % === NUMBER OF RANDOMIZATIONS
    sProcess.options.randomizations.Comment = 'Number of randomizations:';
    sProcess.options.randomizations.Type    = 'value';
    sProcess.options.randomizations.Value   = {1000, '', 0};
    % === STATISTICS APPLIED FOR SAMPLES : TYPE
    % The statistic that is computed for each sample in each random reshuffling of the data
    sProcess.options.statistictype.Comment = {'Pearson', 'Spearman', ''};   % More options: See below 'statcfg.statistic'
    sProcess.options.statistictype.Type    = 'radio_line';
    sProcess.options.statistictype.Value   = 1;
    % === TAIL FOR THE TEST STATISTIC
    sProcess.options.tail.Comment  = {'One-tailed (-)', 'Two-tailed', 'One-tailed (+)', ''; ...
                                      'one-', 'two', 'one+', ''};
    sProcess.options.tail.Type     = 'radio_linelabel';
    sProcess.options.tail.Value    = 'two';
    % ===== MULTIPLE COMPARISONS OPTIONS =====
    sProcess.options.label3.Comment = '<BR><B><U>Correction for multiple comparisons</U></B>:';
    sProcess.options.label3.Type    = 'label';
    % === TYPE OF CORRECTION
    sProcess.options.correctiontype.Comment = 'Type of correction: ';   % More options: See below 'statcfg.correctm'
    sProcess.options.correctiontype.Type    = 'combobox';
    sProcess.options.correctiontype.Value   = {2, {'no', 'cluster', 'bonferroni', 'fdr', 'max', 'holm', 'hochberg'}};
%     % === WAY TO COMBINE SAMPLES OF A CLUSTER
%     % How to combine the single samples that belong to a cluster
%     % 'wcm' refers to 'weighted cluster mass', a statistic that combines cluster size and intensity; see Hayasaka & Nichols (2004) NeuroImage for details.
%     sProcess.options.clusterstatistic.Comment   = {'maxsum', 'maxsize', 'wcm', 'Cluster function: '};  
%     sProcess.options.clusterstatistic.Type      = 'radio_line';
%     sProcess.options.clusterstatistic.Value     = 1;    
    % === MINIMUM NUMBER OF NEIGHBOURING CHANNELS
    sProcess.options.minnbchan.Comment    = 'Min number of neighbours (minnbchan): ';
    sProcess.options.minnbchan.Type       = 'value';
    sProcess.options.minnbchan.Value      = {0, '', 0};
    sProcess.options.minnbchan.InputTypes = {'data', 'timefreq', 'results'};
    % === CLUSTER ALPHA VALUE
    sProcess.options.clusteralpha.Comment = 'Cluster Alpha :';
    sProcess.options.clusteralpha.Type    = 'value';
    sProcess.options.clusteralpha.Value   = {0.05, '', 4};
    
    % Remove average channel option
    if isfield(sProcess.options, 'avgchan')
        sProcess.options = rmfield(sProcess.options, 'avgchan');
    end
end


%% ===== FORMAT COMMENT =====
function Comment = FormatComment(sProcess) %#ok<DEFNU>
    % Get standard stat comment
    Comment = ['FT_' sProcess.options.statistictype.Comment{sProcess.options.statistictype.Value}];
end


%% ===== RUN =====
function sOutput = Run(sProcess, sInputsA, sInputsB) %#ok<DEFNU>
    % Initialize returned variable 
    sOutput = [];
    % Initialize fieldtrip
    bst_ft_init();
    
    % ===== CHECK INPUTS =====
    % Check the number of files in input
    if (length(sInputsA) < 2)
        bst_report('Error', sProcess, sInputsA, 'Not enough files in input.');
        return;
    end
    if (length(sInputsB) > 1)
        bst_report('Error', sProcess, sInputsB, 'Too many files in B. Only one file is allowed.');
        return;
    end
    independentVar=load(file_fullpath(sInputsB.FileName));
    if (length(sInputsA) ~= length(independentVar.Value))
        bst_report('Error', sProcess, sInputsB, 'Number of files in A and number of values of the Variable in B do not match.');
        return;
    end

    
    % ===== GET OPTIONS =====
    % Input options
    if isfield(sProcess.options, 'sensortypes') && isfield(sProcess.options.sensortypes, 'Value')
        OPT.SensorTypes = sProcess.options.sensortypes.Value;
    end
    if isfield(sProcess.options, 'timewindow') && isfield(sProcess.options.timewindow, 'Value') && ~isempty(sProcess.options.timewindow.Value)
        OPT.TimeWindow = sProcess.options.timewindow.Value{1};
    else
        OPT.TimeWindow = [];
    end
    OPT.isAvgTime   = sProcess.options.avgtime.Value;
    OPT.isAbsolute  = sProcess.options.isabs.Value;
    if OPT.isAbsolute
        strAbs = ' abs';
    else
        strAbs = '';
    end
    if isfield(sProcess.options, 'avgchan') && isfield(sProcess.options.avgchan, 'Value')
        OPT.isAvgChan = sProcess.options.avgchan.Value;
    end
    if isfield(sProcess.options, 'avgfreq') && isfield(sProcess.options.avgfreq, 'Value')
        OPT.isAvgFreq = sProcess.options.avgfreq.Value;
    end
    % Scouts
    if isfield(sProcess.options, 'scoutsel') && isfield(sProcess.options.scoutsel, 'Value') && isfield(sProcess.options, 'scoutfunc') && isfield(sProcess.options.scoutfunc, 'Value')
        OPT.ScoutSel = sProcess.options.scoutsel.Value;
        switch (sProcess.options.scoutfunc.Value)
            case 1, OPT.ScoutFunc = 'mean';
            case 2, OPT.ScoutFunc = 'pca';
            case 3, OPT.ScoutFunc = 'all';
        end
    else
        OPT.ScoutSel = [];
        OPT.ScoutFunc = [];
    end
    % Test statistic options
    switch (sProcess.options.statistictype.Value)
        case 1,  OPT.StatisticType  = 'Pearson';  strType = '';
        case 2,  OPT.StatisticType  = 'Spearman';    strType = ' Spearman';
    end
    switch (sProcess.options.tail.Value)
        case {1, 'one-'},  OPT.Tail = -1;   % One-sided (negative)
        case {2, 'two'},   OPT.Tail = 0;    % Two-sided
        case {3, 'one+'},  OPT.Tail = 1;    % One-sided (positive)
    end
    % Cluster statistic options
    OPT.Randomizations     = sProcess.options.randomizations.Value{1};
    OPT.ClusterAlphaValue  = sProcess.options.clusteralpha.Value{1};
    switch (sProcess.options.correctiontype.Value{1})
        case 1,  OPT.Correction = 'no';          strCorrection = ' [uncorrected]';
        case 2,  OPT.Correction = 'cluster';     strCorrection = ' [cluster]';
        case 3,  OPT.Correction = 'bonferroni';  strCorrection = ' [bonferroni]';
        case 4,  OPT.Correction = 'fdr';         strCorrection = ' [fdr]';
        case 5,  OPT.Correction = 'max';         strCorrection = ' [max]';
        case 6,  OPT.Correction = 'holm';        strCorrection = ' [holm]';
        case 7,  OPT.Correction = 'hochberg';    strCorrection = ' [hochberg]';
    end
    if isfield(sProcess.options, 'clusterstatistic') && isfield(sProcess.options.clusterstatistic, 'Value') && ~isempty(sProcess.options.clusterstatistic.Value)
        switch (sProcess.options.clusterstatistic.Value)
            case 1,  OPT.ClusterStatistic = 'maxsum';
            case 2,  OPT.ClusterStatistic = 'maxsize';
            case 3,  OPT.ClusterStatistic = 'wcm';
        end
    else
        OPT.ClusterStatistic = 'maxsum';
    end
    % Neighborhood
    if isfield(sProcess.options, 'minnbchan') && isfield(sProcess.options.minnbchan, 'Value') && iscell(sProcess.options.minnbchan.Value) && ~isempty(sProcess.options.minnbchan.Value)
        OPT.MinNbChan = sProcess.options.minnbchan.Value{1};
    end

    % Number of files
    nFilesA = length(sInputsA);

    % ===== CREATE FIELDTRIP STRUCTURES =====
    % Load all the files in the same structure
    sAllInputs = [sInputsA];
    ftAllFiles = cell(1, length(sAllInputs));
    for i = 1:length(sAllInputs)
        bst_progress('text', sprintf('Reading input files... [%d/%d]', i, length(sAllInputs)));
        % Convert Brainstorm file to FieldTrip structure
        if (i == 1)
            % First call: convert more information
            [ftAllFiles{i}, ResultsMat, VertConn] = out_fieldtrip_results(sAllInputs(i).FileName, OPT.ScoutSel, OPT.ScoutFunc, OPT.TimeWindow, OPT.isAbsolute);
            % Use the information from the first file for all the files
            nComponents = ResultsMat.nComponents;
            GridAtlas   = ResultsMat.GridAtlas;
            RowNames    = ResultsMat.RowNames;
            % Save time vector for output
            if (length(ResultsMat.Time) == 1)
                sfreq = 1000;
            else
                sfreq = 1/(ResultsMat.Time(2) - ResultsMat.Time(1));
            end
            OutTime = ftAllFiles{i}.time;
            if (length(OutTime) == 1)
                OutTime = OutTime + [0, 1/sfreq];
            end
        else
            % Following calls: Just get the source values
            ftAllFiles{i} = out_fieldtrip_results(sAllInputs(i).FileName, OPT.ScoutSel, OPT.ScoutFunc, OPT.TimeWindow, OPT.isAbsolute);
        end
        % Check that something was read
        if isempty(ftAllFiles{i}.pow)
            bst_report('Error', sProcess, sAllInputs(i), 'Nothing read from the file.');
            return;
        end
        % Time average
        if OPT.isAvgTime
            if strcmpi(ftAllFiles{i}.dimord, 'pos_time')
                ftAllFiles{i}.pow  = mean(ftAllFiles{i}.pow, 2);
            elseif strcmpi(ftAllFiles{i}.dimord, 'pos_freq_time')
                ftAllFiles{i}.pow  = mean(ftAllFiles{i}.pow, 3);
            else
                error('todo');
            end
            ftAllFiles{i}.time = ftAllFiles{i}.time(1);
            if (i == 1)
                OutTime = OutTime([1,end]);
            end
        end
        % Check that all the files have the same dimensions as the first one
        if (i > 1)
            if ~isequal(size(ftAllFiles{i}.pow,1), size(ftAllFiles{1}.pow,1))
                bst_report('Error', sProcess, [], sprintf('All the files must have the same number of sources.\nFile #%d has %d sources, file #%d has %d sources.', 1, size(ftAllFiles{1}.pow,1), i, size(ftAllFiles{i}.pow,1)));
                return;
            elseif ~isequal(size(ftAllFiles{i}.pow,2), size(ftAllFiles{1}.pow,2))
                bst_report('Error', sProcess, [], sprintf('All the files must have the same number of time samples.\nFile #%d has %d samples, file #%d has %d samples.', 1, size(ftAllFiles{1}.pow,2), i, size(ftAllFiles{i}.pow,2)));
                return;
            elseif ~isequal(size(ftAllFiles{i}.pow,3), size(ftAllFiles{1}.pow,3))
                bst_report('Error', sProcess, [], sprintf('All the files must have the same number of frequency bins.\nFile #%d has %d samples, file #%d has %d bins.', 1, size(ftAllFiles{1}.pow,3), i, size(ftAllFiles{i}.pow,3)));
                return;
%             elseif isfield(ftAllFiles{1}, 'freq') && (abs(ftAllFiles{1}.freq(1) - ftAllFiles{i}.freq(1)) > 0)
%                 bst_report('Error', sProcess, [], 'The frequency definitions of the input files do not match.');
%                 return;
%             elseif (abs(ftAllFiles{1}.time(1) - ftAllFiles{i}.time(1)) > 1e-6)
%                 bst_report('Error', sProcess, [], 'The time definitions of the input files do not match.');
%                 return;
            % Only one time point: use the time of the first file
            elseif (length(ftAllFiles{i}.time) == 1)
                ftAllFiles{i}.time = ftAllFiles{1}.time;
            end
        end
    end
            
    % ===== CALL FIELDTRIP =====
    bst_progress('text', 'Calling FieldTrip function: ft_sourcestatistics...');
    % Input options
    statcfg = struct();
    statcfg.method            = 'montecarlo';
    statcfg.numrandomization  = OPT.Randomizations;
    statcfg.statistic         = 'ft_statfun_correlationT';
    statcfg.tail              = OPT.Tail;
    statcfg.correcttail       = 'prob';
    statcfg.parameter         = 'pow';
    statcfg.type              = OPT.StatisticType;
    %statcfg.computestat       = 'yes';
    %statcfg.computecritval    = 'no';
    %statcfg.computeprob       = 'no';

    % Define the design of the experiment
    statcfg.design      = zeros(1, nFilesA);
    independentVar=load(file_fullpath(sInputsB.FileName));
    statcfg.design(1,:) = independentVar.Value;
    statcfg.ivar        = 1;   % the one and only row in cfg.design contains the independent variable
    
    % Correction for multiple comparisons
    statcfg.correctm = OPT.Correction;
    switch (OPT.Correction)
        case 'no'
        case 'cluster'
            % Define parameters for cluster statistics
            statcfg.clusteralpha     = OPT.ClusterAlphaValue;
            statcfg.clustertail      = statcfg.tail;
            statcfg.minnbchan        = OPT.MinNbChan; 
            statcfg.clusterstatistic = OPT.ClusterStatistic;
            % Keep only the selected vertices in the vertex adjacency matrix
            if ~isempty(VertConn) && isempty(OPT.ScoutSel)
                statcfg.connectivity = full(VertConn);
            else
                statcfg.connectivity = zeros(size(ftAllFiles{1}.pos, 1)); 
            end
        case 'bonferroni'
        case 'fdr'
        case 'max'
        case 'holm'
        case 'hochberg'
    end

    % Main function that will compute the statistics
    ftStat = ft_sourcestatistics(statcfg, ftAllFiles{:});
    % Error management
    if ~isfield(ftStat, 'prob') || ~isfield(ftStat, 'stat') || isempty(ftStat.prob) || isempty(ftStat.stat)
        bst_report('Error', sProcess, [], 'Unknown error: The function ft_sourcestatistics did not return anything.');
        return;
    end
    % Apply thresholded mask on the p-values (the prob map is already thresholded for clusters)
    if ~ismember(OPT.Correction, {'no', 'cluster'})
        ftStat.prob(~ftStat.mask) = .999;
    end
    % Replace NaN values with zeros
    ftStat.stat(isnan(ftStat.stat)) = 0;
    
    % Time-frequency: Permute matrices back
    if strcmpi(sInputsA(1).FileType, 'timefreq')
        ftStat.prob = permute(ftStat.prob, [1 3 2]);
        ftStat.stat = permute(ftStat.stat, [1 3 2]);
        if isfield(ftStat, 'posclusterslabelmat') && ~isempty(ftStat.posclusterslabelmat)
            ftStat.posclusterslabelmat = permute(ftStat.posclusterslabelmat, [1 3 2]);
        end
        if isfield(ftStat, 'negclusterslabelmat') && ~isempty(ftStat.negclusterslabelmat)
            ftStat.negclusterslabelmat = permute(ftStat.negclusterslabelmat, [1 3 2]);
        end
        if isfield(ftStat, 'cirange') && ~isempty(ftStat.cirange)
            ftStat.cirange = permute(ftStat.cirange, [1 3 2]);
        end
        if isfield(ftStat, 'mask') && ~isempty(ftStat.mask)
            ftStat.mask = permute(ftStat.mask, [1 3 2]);
        end
        if isfield(ftStat, 'ref') && ~isempty(ftStat.ref)
            ftStat.ref = permute(ftStat.ref, [1 3 2]);
        end
    end
    
    % === OUTPUT STRUCTURE ===
    sOutput = db_template('statmat');
    % === BACKUP ENTIRE FT OUTPUT ===
    sOutput.ftBackup = ftStat;    
    % Store t- and p-values
    sOutput.pmap = ftStat.prob;
    sOutput.tmap = ftStat.stat;
    % Store other stuff
    sOutput.df            = [];
    sOutput.Correction    = OPT.Correction;
    sOutput.ColormapType  = 'stat2';
    sOutput.DisplayUnits  = 't';
    % Output type
    if ~isempty(OPT.ScoutSel)
        sOutput.Type = 'matrix';
        sOutput.Description = RowNames;
    else
        sOutput.Type = sInputsA(1).FileType;
    end
    % Source model fields
    sOutput.nComponents = nComponents;
    sOutput.GridAtlas   = GridAtlas;
    % Time: If there is only one time point, replicate to have two
    if (length(ftStat.time) == 1)
        sOutput.Time = [OutTime(1), OutTime(end)];
        sOutput.tmap = [sOutput.tmap(:,1,:), sOutput.tmap(:,1,:)];
        sOutput.pmap = [sOutput.pmap(:,1,:), sOutput.pmap(:,1,:)];
    else
        sOutput.Time = ftStat.time;
    end
    % Save clusters
    if isfield(ftStat, 'posclusters')
        sOutput.StatClusters.posclusters         = ftStat.posclusters;
        sOutput.StatClusters.posclusterslabelmat = ftStat.posclusterslabelmat;
        sOutput.StatClusters.posdistribution     = ftStat.posdistribution;
    end
    if isfield(ftStat, 'negclusters')
        sOutput.StatClusters.negclusters         = ftStat.negclusters;
        sOutput.StatClusters.negclusterslabelmat = ftStat.negclusterslabelmat;
        sOutput.StatClusters.negdistribution     = ftStat.negdistribution;
    end
    % Save FieldTrip configuration structure
    sOutput.cfg = statcfg;
    if isfield(sOutput.cfg, 'connectivity')
        sOutput.cfg = rmfield(sOutput.cfg, 'connectivity');
    end
    if isfield(ftStat, 'cfg') && isfield(ftStat.cfg, 'version')
        sOutput.cfg.version = ftStat.cfg.version;
    end
    % Save options
    sOutput.Options = OPT;
    % Last message
    bst_progress('text', 'Saving results...');
end




