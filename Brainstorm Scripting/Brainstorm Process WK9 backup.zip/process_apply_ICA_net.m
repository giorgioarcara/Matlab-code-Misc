function varargout = process_apply_ICA_net( varargin )
% PROCESS_ABSOLUTE: Return the absolute values for the input files.

% @=============================================================================
% This function is part of the Brainstorm software:
% https://neuroimage.usc.edu/brainstorm
% 
% Copyright (c)2000-2019 University of Southern California & McGill University
% This software is distributed under the terms of the GNU General Public License
% as published by the Free Software Foundation. Further details on the GPLv3
% license can be found at http://www.gnu.org/copyleft/gpl.html.
% 
% FOR RESEARCH PURPOSES ONLY. THE SOFTWARE IS PROVIDED "AS IS," AND THE
% UNIVERSITY OF SOUTHERN CALIFORNIA AND ITS COLLABORATORS DO NOT MAKE ANY
% WARRANTY, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF
% MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, NOR DO THEY ASSUME ANY
% LIABILITY OR RESPONSIBILITY FOR THE USE OF THIS SOFTWARE.
%
% For more information type "brainstorm license" at command prompt.
% =============================================================================@
%
% Authors: Giorgio Arcara

eval(macro_method);
end


%% ===== GET DESCRIPTION =====
function sProcess = GetDescription() %#ok<DEFNU>
    % Description the process
    sProcess.Comment     = 'Apply ICA - NET';
    sProcess.FileTag     = 'NET_ICA';
    sProcess.Category    = 'Filter';
    sProcess.SubGroup    = 'NET';
    sProcess.Index       = 100;
    sProcess.Description = '';
    % Definition of the input accepted by this process
    sProcess.InputTypes  = { 'raw'};
    sProcess.OutputTypes = {'raw'};
    sProcess.nInputs     = 1;
    sProcess.nMinFiles   = 1;
    % Default values for some options


end


%% ===== FORMAT COMMENT =====
function Comment = FormatComment(sProcess) %#ok<DEFNU>
    Comment = sProcess.Comment;
end


%% ===== RUN =====
function sInput = Run(sProcess, sInput) %#ok<DEFNU>
    % Opposite values
    
    % get projector data
    % proj = in_bst_data(file_fullpath(sInput.ChannelFile), 'Projector');
    
    % get NET_ICA data
    res = in_bst_data(file_fullpath(sInput.ChannelFile), 'NET_ICA');

% COMMENTED PART: I don't rely on projectors but for visualization
%     Labels = {Proj.Projector.Comment};
%     Labels_ind = find(~cellfun(@isempty, regexp(Labels, 'Infomax_NET')));
%     
%     if length(Labels_ind)>1
%         bst_error('There are two NET-ICA unmixing matrices, please delete one');
%     end;
    
     % YOU MUST ADD CHANNELFLAG IN THE OUTPUT SAVE IN NET_ICA SHOULD BE %iChannels
    
    sInput.A = Compute(sInput.A, res.NET_ICA)
   
      

end



%% ===== COMPUTE =====
% USAGE:  x = process_detrend('Compute', F, iTime=[])
function F = Compute(F, R)
     
    % R is the struct with results from NET_ICA
    %
    % PC os whitening * F
    PC = inv(R.dewhitening)*F(R.iChannels,:);

    IC = R.unmixing*PC(1:R.n_pcs, :);
    F(R.iChannels,:) = F(R.iChannels,:) - R.dewhitening(: , 1:R.n_pcs)*R.mixing(:,R.bad_ics)*IC(R.bad_ics,:);

    %F(R.iChannels(1:size(IC, 1)),:) = IC;

end




