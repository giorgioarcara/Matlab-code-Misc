function varargout = process_replace_eeglabels( varargin )
% PROCESS_import_EVENTS: import channel file .
%
% USAGE:     sProcess = process_import_channel('GetDescription')
%                       process_import_channel('Run', sProcess, sInputs)

% @=============================================================================
%
% Authors: Giorgio Arcara, 2018, version 0.1

eval(macro_method);
end


%% ===== GET DESCRIPTION =====
function sProcess = GetDescription() %#ok<DEFNU>
% Description the process
sProcess.Comment     = 'replace EEG labels';
sProcess.FileTag     = '';
sProcess.Category    = 'Custom';
sProcess.SubGroup    = 'Giorgio';
sProcess.Index       = 1021;
%sProcess.Description = 'http://neuroimage.usc.edu/brainstorm/SelectFiles#How_to_control_the_output_file_names';
% Definition of the input accepted by this process
sProcess.InputTypes  = {'raw', 'data'};
sProcess.OutputTypes = {'raw', 'data'};
sProcess.nInputs     = 1;
sProcess.nMinFiles   = 1;
%sProcess.Description = 'https://sites.google.com/site/giorgioarcara/erpr';
% Definition of the options
% Instructions
sProcess.options.Instructions.Comment='To import channel file from a .mat file';
sProcess.options.Instructions.Type='label';

%INPUT
sProcess.options.chanlabels.Comment = 'insert electrode labels';
sProcess.options.chanlabels.Type    = 'text';
sProcess.options.chanlabels.Value   = '';


sProcess.options.Explanation.Comment=['<B>NOTE</B>: you can find some example within the process'];
sProcess.options.Explanation.Type='label';

end


%% LABEL EXAMPLES

%el_labels = {'Fp1', 'Fpz', 'Fp2', 'AF7', 'AF3', 'Afz', 'AF4', 'AF8', 'F7', 'F5', 'F1', 'Fz', 'F2', 'F6', 'F8', 'FT7', 'FC5', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4','FC6', 'FT8', 'T7', 'C3', 'C1', 'Cz', 'C2', 'C4', 'T8', 'TP9', 'TP7', 'CP5', 'CP3', 'CP1', 'CP2', 'CP4', 'CP6', 'TP8', 'TP10', 'P7', 'P5', 'P1', 'Pz','P2', 'P6', 'P8', 'P03', 'POz', 'PO4', 'PO7', 'O1', 'Oz', 'O2', 'PO8'};


%% ===== FORMAT COMMENT =====
function Comment = FormatComment(sProcess) %#ok<DEFNU>
Comment = sProcess.Comment;
end
% the comment is apparently a mandatory part of a brainstorm process.

%% ===== RUN =====
function OutputFiles = Run(sProcess, sInputs) %#ok<DEFNU>

OutputFiles = [];

new_eeg_labels = eval(['{', sProcess.options.chanlabels.Value, '}']);

% determine study names
% CRUCIAL PART!!!
iStudies = unique([sInputs.iStudy]);
sStudies = bst_get('Study', iStudies);


for iStudy = 1:length(sStudies)
    
    %     % get current Study
    curr_iStudy = iStudies(iStudy)
    %
    Channel = bst_get('ChannelForStudy',   curr_iStudy);
    ChannelFile = in_bst_data(Channel.FileName);
    
    ChannelNames = {ChannelFile.Channel.Name};
    EEGchan = regexpi(ChannelNames, 'EEG');
    EEGchanind = find(~cellfun(@isempty, EEGchan));
    
    
    if length(EEGchanind)~=length(new_eeg_labels)
        bst_report('Error', sProcess, sInputs, ['The number of channel labels supplied is different from the number of EEG channels.<BR>', ...
        num2str(length(new_eeg_labels)), ' vs ', num2str(length(EEGchanind)),  '<BR>. Please Check']);
    end
    
    for iChan = 1:length(EEGchanind)
        ChannelFile.Channel(EEGchanind(iChan)).Name = new_eeg_labels{iChan}
    end;
    
    bst_save(file_fullpath(Channel.FileName), ChannelFile, 'v6', 1);
    %
    
    
end;

end



