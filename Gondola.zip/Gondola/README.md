# GONDOLA

![alt text](Logo/Gondola_logo.png)

Gondola is a toolbox to facilitate Brain network analysis (and exploration) in Matlab/Octave.
Gondola provides an easy structure to develop code-based network analysis to allow easy to write and reproducible code. It also allows to navigate through other existing toolboxes (Brain Connectivity Toolbox, Network Based Statistics, BrainNetViewer).


